#ifndef _TPMSET_H
#define _TPMSET_H
void init_tpm(int cnv);
#endif