#ifndef _TIMERS_H
#define _TIMERS_H

#include <MKL25Z4.H>
#include "pinset.h"


static inline void systickset(void);

#endif