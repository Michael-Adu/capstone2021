#ifndef UART_H
#define UART_H

#include <MKL25Z4.H>
#include <stdio.h>
#include "queue.h"

void init_UART0(void);

#endif
	